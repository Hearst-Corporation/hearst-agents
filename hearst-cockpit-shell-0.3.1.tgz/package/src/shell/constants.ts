/**
 * Constantes Cockpit partagees.
 * CT_ACCENT_DEFAULT : couleur accent fallback identique a --ct-accent dans tokens.css.
 * Utilisee uniquement comme fallback JS avant que le ThemeAccent monte les CSS vars.
 */
export const CT_ACCENT_DEFAULT = "#be123c";
