"use client";

import { useSyncExternalStore, useEffect, useRef, useState } from "react";
import {
  subscribe as subActive,
  getSnapshot as getActive,
  getServerSnapshot as getActiveSSR,
  setActive,
} from "../stores/activeProductStore";
import { HearstMark } from "./HearstMark";
import { useCockpit } from "./context";

/**
 * Rail gauche — accordéon lanceur de la suite Hearst.
 *
 * - Lanceur OUVERT : rail élargi, tous les produits (hache + nom). Clic produit
 *   → on entre dans le produit, le lanceur se replie.
 * - Lanceur REPLIÉ : rail 88px, en haut le badge du produit actif (sa couleur,
 *   son nom) qui sert de toggle ; reclic → le lanceur se redéploie.
 */
export function RailLeft() {
  const { products, appId, getProduct, version } = useCockpit();
  const active = useSyncExternalStore(subActive, getActive, getActiveSSR);

  const otherProducts = products.filter((p) => p.id !== appId);
  const current = getProduct(active);
  const inProduct = current.id !== appId;

  const top = inProduct ? current : getProduct(appId);
  const versionLabel = version ? `v${version.replace(/^v/, "")}` : "";
  const tooltip = inProduct ? "Retour au hub" : `${top.name}${versionLabel ? ` · ${versionLabel}` : ""}`;

  return (
    <aside className="ct-rail-left">
      <button
        type="button"
        className="ct-rail-top"
        title={tooltip}
        aria-label={tooltip}
        onClick={() => {
          if (inProduct) setActive(appId);
        }}
        style={{ ["--p-color" as string]: top.color }}
        {...(versionLabel ? { "data-version": versionLabel } : {})}
      >
        <span className="ct-rail-top-badge">
          <HearstMark size={28} />
        </span>
      </button>

      <nav className="ct-rail-list" aria-label="Produits Hearst" style={{ alignItems: "center" }}>
        {otherProducts.map((p) => {
          const on = active === p.id;
          return (
            <button
              key={p.id}
              type="button"
              className={`ct-rail-row-mini${on ? " active" : ""}`}
              title={p.name}
              aria-pressed={on}
              onClick={() => setActive(p.id)}
              style={{ ["--p-color" as string]: p.color }}
            >
              <HearstMark size={22} />
            </button>
          );
        })}
        <button
          type="button"
          className="ct-rail-row-mini"
          title="Configurer les actions rapides"
          aria-label="Configurer les actions rapides"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
        </button>
      </nav>

      <div className="ct-spacer" />
      <UserBadge appId={appId} />
    </aside>
  );
}

/**
 * Badge utilisateur en bas du rail gauche.
 * - 1er clic : navigue vers /profile + s'arme (rouge + icône logout).
 * - 2e clic sur le badge armé : déconnexion Supabase + redirect /login.
 * - Clic ailleurs OU 5s sans interaction → désarme automatiquement.
 */
function UserBadge({ appId }: { appId: string }) {
  const { userEmail, onLogout } = useCockpit();
  const initials = userEmail ? computeInitials(userEmail) : "";
  const [armed, setArmed] = useState<boolean>(false);
  const armRef = useRef<HTMLButtonElement>(null);
  const timerRef = useRef<number | null>(null);

  // Quand armé : timer 5s + listener click document pour désarmer.
  useEffect(() => {
    if (!armed) return;

    timerRef.current = window.setTimeout(() => setArmed(false), 5000);

    const onDocClick = (e: MouseEvent) => {
      if (armRef.current && !armRef.current.contains(e.target as Node)) {
        setArmed(false);
      }
    };
    document.addEventListener("click", onDocClick);

    return () => {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current);
      document.removeEventListener("click", onDocClick);
    };
  }, [armed]);

  async function handleClick(e: React.MouseEvent) {
    e.stopPropagation();

    if (armed) {
      if (onLogout) {
        onLogout();
      } else {
        window.location.href = "/login";
      }
      return;
    }

    // 1er clic — armer + naviguer vers le profil si on n'y est pas déjà.
    setArmed(true);
    if (window.location.pathname !== "/profile") {
      window.location.href = "/profile";
    }
  }

  const display = initials || (appId || "HC").slice(0, 2).toUpperCase();

  return (
    <button
      ref={armRef}
      type="button"
      className={`ct-avatar${armed ? " active" : ""}`}
      title={armed ? "Cliquer pour se déconnecter" : "Profil & réglages"}
      aria-label={armed ? "Cliquer pour se déconnecter" : "Profil & réglages"}
      onClick={handleClick}
    >
      {armed ? <LogoutIcon /> : display}
    </button>
  );
}

function LogoutIcon() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  );
}

/**
 * Calcule les initiales depuis un email.
 * - "adrien@hearstcorporation.io" → "AH" (1re lettre prénom + 1re lettre domaine)
 * - "john.doe@x.com" → "JD"
 * - fallback : 2 premières lettres du local-part.
 */
function computeInitials(email: string): string {
  const local = email.split("@")[0] ?? "";
  const parts = local.split(/[._-]/).filter(Boolean);
  if (parts.length >= 2 && parts[0] && parts[1]) {
    return (parts[0][0]! + parts[1][0]!).toUpperCase();
  }
  return local.slice(0, 2).toUpperCase();
}
