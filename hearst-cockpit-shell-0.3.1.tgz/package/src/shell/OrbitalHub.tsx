"use client";

import type React from "react";
import "./OrbitalHub.css";

const REGIONS = [
  { name: "America",      filled: 65, total: 80, count: "1,124" },
  { name: "Europe",       filled: 55, total: 80, count: "958"   },
  { name: "Asia-Pacific", filled: 45, total: 80, count: "765"   },
] as const;

const TREND_BARS = [
  { height: 40, active: false },
  { height: 30, active: false },
  { height: 50, active: false },
  { height: 80, active: true  },
  { height: 45, active: false },
  { height: 40, active: false },
] as const;

export function OrbitalHub() {
  return (
    <div className="orbital-hub-root">
      <div className="ct-ambient-glow orbital-hub-glow" />

      {/* HEADER & KPIs */}
      <div className="orbital-hub-content">

        {/* Jeu de désinformation (Placeholder) dans le header */}
        <div className="orbital-hub-misinfo-row">
          <div className="orbital-hub-misinfo-card">
            <div className="orbital-hub-misinfo-dot" />
            <div>
              <h3 className="orbital-hub-misinfo-title">Misinformation Game</h3>
              <div className="orbital-hub-misinfo-sub">Active session: 3 players</div>
            </div>
          </div>
        </div>

        {/* Status bar */}
        <div className="orbital-hub-status-bar">
          <h2 className="orbital-hub-section-title">SYSTEM STATUS</h2>
          <div className="orbital-hub-operational">
            <div className="orbital-hub-operational-dot" />
            OPERATIONAL
          </div>
        </div>

        {/* KPI Grid */}
        <div className="orbital-hub-kpi-grid">

          {/* Column 1 — Processing + Readiness */}
          <div className="orbital-hub-kpi-col">
            <div className="orbital-hub-kpi-card orbital-hub-kpi-card--center">
              <h3 className="ct-kpi-label ct-kpi-label--xl">Processing</h3>
              <div className="orbital-hub-spinner-wrap">
                <svg viewBox="0 0 100 100" style={{ width: "100%", height: "100%", transform: "rotate(-90deg)" }}>
                  <circle cx="50" cy="50" r="45" fill="none" className="orbital-hub-svg-track" strokeWidth="2" />
                  <circle
                    cx="50" cy="50" r="45" fill="none"
                    className="orbital-hub-svg-fill"
                    strokeWidth="2"
                    strokeDasharray="283"
                    strokeDashoffset="200"
                    style={{ animation: "spin 2s linear infinite", transformOrigin: "50% 50%" }}
                  />
                </svg>
                <div className="orbital-hub-spinner-dot" />
              </div>
            </div>

            <div className="orbital-hub-kpi-card orbital-hub-kpi-card--center">
              <div className="orbital-hub-donut-wrap">
                <svg viewBox="0 0 100 100" style={{ width: "100%", height: "100%", transform: "rotate(-90deg)" }}>
                  <circle cx="50" cy="50" r="40" fill="none" className="orbital-hub-svg-track" strokeWidth="6" />
                  <circle cx="50" cy="50" r="40" fill="none" className="orbital-hub-svg-fill" strokeWidth="6" strokeDasharray="251" strokeDashoffset="55" />
                </svg>
                <div className="orbital-hub-donut-label">
                  <div className="orbital-hub-donut-pct">78%</div>
                  <div className="orbital-hub-donut-sub">Readiness</div>
                </div>
              </div>
            </div>
          </div>

          {/* Column 2 — Data volume + Recent activity */}
          <div className="orbital-hub-kpi-col orbital-hub-kpi-col--wide">
            <div className="orbital-hub-kpi-card">
              <h3 className="ct-kpi-label">Data volume</h3>
              <div className="orbital-hub-vol-bars">
                <div className="orbital-hub-vol-css" style={{ "--vol-filled": "75%" } as React.CSSProperties} />
              </div>
              <div className="orbital-hub-vol-meta">
                <span>280.5</span>
                <span>of 560TB</span>
              </div>
              <div className="orbital-hub-vol-note">Overall progress 50%</div>
            </div>

            <div className="orbital-hub-kpi-card">
              <div className="orbital-hub-activity-header">
                <h3 className="ct-kpi-label ct-kpi-label--tight">Recent activity</h3>
                <div className="orbital-hub-activity-viewall">View all</div>
              </div>
              <div className="orbital-hub-activity-list">
                <div className="orbital-hub-activity-row orbital-hub-activity-row--bordered">
                  <div>
                    <div className="orbital-hub-activity-title">Satellite SAT-07 sync complete</div>
                    <div className="orbital-hub-activity-time">14:32:08</div>
                  </div>
                  <div className="orbital-hub-activity-badge">OK</div>
                </div>
                <div className="orbital-hub-activity-row orbital-hub-activity-row--bordered">
                  <div>
                    <div className="orbital-hub-activity-title">Ground unit GU-1284 deployed</div>
                    <div className="orbital-hub-activity-time">14:32:08</div>
                  </div>
                  <div className="orbital-hub-activity-badge">OK</div>
                </div>
                <div className="orbital-hub-activity-row orbital-hub-activity-row--bordered">
                  <div>
                    <div className="orbital-hub-activity-title">Air asset AA-234 patrol complete</div>
                    <div className="orbital-hub-activity-time">14:32:08</div>
                  </div>
                  <div className="orbital-hub-activity-badge">OK</div>
                </div>
                <div className="orbital-hub-activity-row">
                  <div>
                    <div className="orbital-hub-activity-title">Anomaly detected sector 7-G</div>
                    <div className="orbital-hub-activity-time">14:32:08</div>
                  </div>
                  <div className="orbital-hub-activity-badge">ALERT</div>
                </div>
              </div>
            </div>
          </div>

          {/* Column 3 — Est. time + Operations trend + Transfer speed */}
          <div className="orbital-hub-kpi-col">
            <div className="orbital-hub-kpi-card">
              <h3 className="ct-kpi-label">Est. time</h3>
              <div className="ct-kpi-value">0h:12m:44s</div>
              <div className="orbital-hub-est-note">Less than 15 min.</div>
            </div>

            <div className="orbital-hub-kpi-card">
              <h3 className="ct-kpi-label">Operations trend</h3>
              <div className="ct-kpi-value ct-kpi-value--md-mb">2,846</div>
              <div className="orbital-hub-trend-bars">
                {TREND_BARS.map((bar, i) => (
                  <div
                    key={i}
                    className={`orbital-hub-trend-bar ${bar.active ? "orbital-hub-trend-bar--active" : ""}`}
                    style={{ height: `${bar.height}%` }}
                  >
                    {bar.active && (
                      <div className="orbital-hub-trend-tooltip">Jan 30, 2027</div>
                    )}
                    <div className={`orbital-hub-trend-cap ${bar.active ? "orbital-hub-trend-cap--active" : ""}`} />
                  </div>
                ))}
              </div>
            </div>

            <div className="orbital-hub-kpi-card">
              <h3 className="ct-kpi-label">Transfer speed</h3>
              <div className="ct-kpi-value">
                36<span className="orbital-hub-kpi-value-unit">GB/S</span>
              </div>
            </div>
          </div>
        </div>

        {/* Region progress bars */}
        <div className="orbital-hub-regions">
          {REGIONS.map((r) => (
            <div key={r.name} className="orbital-hub-region-row">
              <div className="orbital-hub-region-name">{r.name}</div>
              <div className="orbital-hub-region-track">
                <div
                  className="orbital-hub-region-bar"
                  style={{ "--filled": `${((r.filled / r.total) * 100).toFixed(2)}%` } as React.CSSProperties}
                />
              </div>
              <div className="orbital-hub-region-count">{r.count}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
