"use client";

import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  subscribe,
  getSnapshot,
  getServerSnapshot,
  setDefaultActive,
  setActive,
} from "../stores/activeProductStore";
import { CockpitContext } from "./context";
import { RailLeft } from "./RailLeft";
import { CenterPanel } from "./CenterPanel";
import { RailRight } from "./RailRight";
import { ThemeAccent } from "./ThemeAccent";
import { HubBottomBar } from "./HubBottomBar";
import type { CockpitShellProps, CockpitProduct } from "./types";
import { CT_ACCENT_DEFAULT } from "./constants";

/**
 * `<CockpitShell>` — point d'entrée unique.
 *
 * Mode standard (défaut) : Rail gauche + centre + rail droit (chat Kimi).
 * Mode `headless: true` : Context + ThemeAccent uniquement, pour les apps
 * avec un shell custom (ex: Helm visionOS).
 */
export function CockpitShell({
  children,
  products,
  appId,
  chatConfig,
  renderActiveProduct,
  userEmail,
  onLogout,
  version,
  headless = false,
}: CockpitShellProps) {
  const productsList = products ?? [];

  // Fixe le défaut du store actif sur l'appId courante (avant le 1er render).
  useEffect(() => {
    setDefaultActive(appId);
  }, [appId]);

  // Détecte Electron : la bande de glisse n'a de sens qu'en mode desktop.
  const [isElectron, setIsElectron] = useState(false);
  /* eslint-disable react-hooks/set-state-in-effect -- Electron detection, window absent côté SSR */
  useEffect(() => {
    setIsElectron(
      typeof window !== "undefined" &&
      typeof (window as unknown as { electron?: unknown }).electron === "object",
    );
  }, []);
  /* eslint-enable react-hooks/set-state-in-effect */

  const active = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  // Helper getProduct memoizé : O(1) si on construit une Map.
  const ctx = useMemo(() => {
    const map = new Map<string, CockpitProduct>();
    for (const p of productsList) map.set(p.id, p);
    const fallback: CockpitProduct = map.get(appId) ?? productsList[0] ?? {
      id: appId,
      name: appId,
      short: appId.slice(0, 2).toUpperCase(),
      color: CT_ACCENT_DEFAULT,
    };
    return {
      products: productsList,
      appId,
      chatConfig: chatConfig ?? {},
      userEmail,
      onLogout,
      version,
      getProduct: (id: string): CockpitProduct => map.get(id) ?? fallback,
    };
  }, [productsList, appId, chatConfig, userEmail, onLogout, version]);

  // Headless : pas de layout, juste Context + ThemeAccent.
  // L'app pose son propre shell + data-product. ThemeAccent dérive --ct-accent
  // du `data-product` posé en amont par l'app.
  if (headless) {
    return (
      <CockpitContext.Provider value={ctx}>
        <ThemeAccent />
        {children}
      </CockpitContext.Provider>
    );
  }

  const inProduct = active !== appId;

  return (
    <CockpitContext.Provider value={ctx}>
      <div className={`ct-root${isElectron ? " ct-electron" : " ct-web"}`}>
        <ThemeAccent />
        {isElectron && <div className="ct-drag" />}
        <div className="ct-ambient-deep" />
        <div className="ct-ambient-glow" />
        <div className={`ct-panels-row${inProduct ? " ct-immersif" : ""}`}>
          <RailLeft />
          <CenterPanel {...(renderActiveProduct !== undefined ? { renderProduct: renderActiveProduct } : {})}>
            {children}
          </CenterPanel>
          <RailRight />
        </div>
        {inProduct && (
          <button
            type="button"
            className="ct-master-fab"
            onClick={() => setActive(appId)}
            title="Retour au hub Master"
          >
            Master
          </button>
        )}
        <HubBottomBar />
      </div>
    </CockpitContext.Provider>
  );
}
