"use client";

import { createContext, useContext } from "react";
import type { CockpitProduct } from "./types";
import type { ChatConfig } from "../chat/types";
import { CT_ACCENT_DEFAULT } from "./constants";

export interface CockpitContextValue {
  products: CockpitProduct[];
  appId: string;
  chatConfig: ChatConfig;
  userEmail?: string;
  onLogout?: () => void;
  /** Optionnel : version de l'app affichée en tooltip au hover du bouton launcher du rail gauche. */
  version?: string;
  /** Helper : produit par id, fallback sur l'appId si inconnu, sinon premier produit. */
  getProduct: (id: string) => CockpitProduct;
}

const HUB_FALLBACK: CockpitProduct = {
  id: "hub",
  name: "Hearst Corporation",
  short: "HC",
  color: CT_ACCENT_DEFAULT,
};

export const CockpitContext = createContext<CockpitContextValue>({
  products: [HUB_FALLBACK],
  appId: "hub",
  chatConfig: {},
  getProduct: () => HUB_FALLBACK,
});

export function useCockpit(): CockpitContextValue {
  return useContext(CockpitContext);
}
