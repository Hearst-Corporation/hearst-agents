"use client";

import { useSyncExternalStore } from "react";
import {
  subscribe,
  getSnapshot,
  getServerSnapshot,
  setActive,
} from "../stores/activeProductStore";
import { useCockpit } from "./context";

interface Props {
  /**
   * Si true, masque la pastille du produit actif (default false → toutes les
   * pastilles affichées avec l'active visuellement distincte).
   */
  hideActive?: boolean;
  /**
   * Optional click handler. Si fourni, appelé à la place du comportement
   * par défaut (window.location.href = product.url || setActive(product.id)).
   */
  onProductClick?: (productId: string) => void;
}

/**
 * `<ProductLauncherBar>` — barre de lancement cross-produits.
 *
 * Affiche une pastille cliquable par produit de `useCockpit().products`.
 * - Click : si `product.url` défini → navigate ; sinon → `setActive(product.id)`.
 * - Position : fixed bottom center, glass dépoli, scrollable horizontalement
 *   si plus de 12 produits.
 * - Le produit actif (`active === product.id`) a un anneau d'accent visible.
 */
export function ProductLauncherBar({ hideActive = false, onProductClick }: Props = {}) {
  const active = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const { products } = useCockpit();

  if (!products.length) return null;

  const visible = hideActive ? products.filter((p) => p.id !== active) : products;
  if (!visible.length) return null;

  return (
    <div className="ct-launcher-bar" role="navigation" aria-label="Hearst products">
      <div className="ct-launcher-bar-track">
        {visible.map((product) => {
          const isActive = product.id === active;
          return (
            <button
              key={product.id}
              type="button"
              className={`ct-launcher-pill${isActive ? " active" : ""}`}
              style={{ "--p-color": product.color } as React.CSSProperties}
              title={product.name}
              aria-current={isActive ? "page" : undefined}
              onClick={() => {
                if (onProductClick) {
                  onProductClick(product.id);
                  return;
                }
                if (product.url) {
                  window.location.href = product.url;
                  return;
                }
                setActive(product.id);
              }}
            >
              <span className="ct-launcher-pill-short">{product.short}</span>
              <span className="ct-launcher-pill-name">{product.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
